export { default as FallingBunnies } from "./FallingBunnies";
export type { FallingBunniesProps } from "./types";
